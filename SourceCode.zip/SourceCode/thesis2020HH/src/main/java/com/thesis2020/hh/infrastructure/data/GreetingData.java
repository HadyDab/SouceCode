package com.thesis2020.hh.infrastructure.data;

public class GreetingData {

    public final String message;
    public final String description;


    public GreetingData(final String message, final String description){
        this.message = message;
        this.description = description;
    }



}
