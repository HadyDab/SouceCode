package com.thesis2020.hh.infrastructure;

import java.util.Properties;

import com.thesis2020.hh.infrastructure.persistence.CommandModelStateStoreProvider;
import com.thesis2020.hh.infrastructure.persistence.QueryModelStateStoreProvider;
import io.vlingo.lattice.model.stateful.StatefulTypeRegistry;
import com.thesis2020.hh.resource.GreetingResource;
import com.thesis2020.hh.resource.HelloResources;

import io.vlingo.actors.Configuration;
import io.vlingo.actors.GridAddressFactory;
import io.vlingo.actors.Stage;
import io.vlingo.actors.World;
import io.vlingo.actors.plugin.PluginProperties;
import io.vlingo.actors.plugin.mailbox.agronampscarrayqueue.ManyToOneConcurrentArrayQueuePlugin.ManyToOneConcurrentArrayQueuePluginConfiguration;
import io.vlingo.actors.plugin.mailbox.concurrentqueue.ConcurrentQueueMailboxPlugin.ConcurrentQueueMailboxPluginConfiguration;
import io.vlingo.common.identity.IdentityGeneratorType;
import io.vlingo.http.resource.Configuration.Sizing;
import io.vlingo.http.resource.Configuration.Timing;
import io.vlingo.http.resource.Resources;
import io.vlingo.http.resource.Server;

public class Bootstrap {
  private static Bootstrap instance;
  private static int DefaultPort = 18080;

  private final Server server;
  private final World world;

  public Bootstrap(final int port) throws Exception {
	  
//	  final Properties properties = new Properties();
//	  properties.setProperty("defaultMailbox", "true");
//	  properties.setProperty("dispatcherThrottlingCount", "1");
//	  properties.setProperty("numberOfDispatchersFactor", "4");
//	  properties.setProperty("numberOfDispatchers", "0");
//	  PluginProperties pluginProperties = new PluginProperties("queueMailbox", properties);
	  
	  final Properties properties = new Properties();
	  properties.setProperty("defaultMailbox", "false");
	  properties.setProperty("dispatcherThrottlingCount", "1");
	  properties.setProperty("numberOfDispatchersFactor", "4");
	  properties.setProperty("numberOfDispatchers", "0");
	  
	  PluginProperties pluginProperties2 = new PluginProperties("jdbcQueueMailbox", properties);
	  
	  Configuration configuration = Configuration.define();
	  
	  ConcurrentQueueMailboxPluginConfiguration jdbcQueueMailbox = ConcurrentQueueMailboxPluginConfiguration.define();
	 
	  ConcurrentQueueMailboxPluginConfiguration queueMailbox = ConcurrentQueueMailboxPluginConfiguration.define();
	 
	  
	  jdbcQueueMailbox.buildWith(configuration, pluginProperties2);
	  
	 
	  configuration.with(jdbcQueueMailbox);
	  
	  queueMailbox.build(configuration);
			  
	  
//	  world = World.start("thesis2020HH", configuration);

//    world = World.startWithDefaults("thesis2020HH");
    world = World.start("thesis2020HH");
    
    final Stage stage =
            world.stageNamed("thesis2020HH", Stage.class, new GridAddressFactory(IdentityGeneratorType.RANDOM));

    final StatefulTypeRegistry statefulTypeRegistry = new StatefulTypeRegistry(world);
    QueryModelStateStoreProvider.using(stage, statefulTypeRegistry);
    CommandModelStateStoreProvider.using(stage, statefulTypeRegistry);

    final GreetingResource greetingResource = new GreetingResource(stage);
    final HelloResources helloResources = new HelloResources(stage);

    Resources allResources = Resources.are(
        greetingResource.routes(),
        helloResources.routes()
    );

//    server = Server.startWith(stage, allResources, port, Sizing.define(), Timing.defineWith(7, 5, 100));
    
    server = Server.startWithAgent(stage, allResources, port, 2);

    Runtime.getRuntime().addShutdownHook(new Thread(() -> {
      if (instance != null) {
        instance.server.stop();

        System.out.println("\n");
        System.out.println("=========================");
        System.out.println("Stopping thesis2020HH.");
        System.out.println("=========================");
      }
    }));
  }

  void stopServer() throws Exception {
    if (instance == null) {
      throw new IllegalStateException("Schemata server not running");
    }
    instance.server.stop();
  }

  public static void main(final String[] args) throws Exception {
    System.out.println("=========================");
    System.out.println("service: thesis2020HH.");
    System.out.println("=========================");

    int port;

    try {
      port = Integer.parseInt(args[0]);
    } catch (Exception e) {
      port = DefaultPort;
      System.out.println("thesis2020HH: Command line does not provide a valid port; defaulting to: " + port);
    }

    instance = new Bootstrap(port);
  }
}
