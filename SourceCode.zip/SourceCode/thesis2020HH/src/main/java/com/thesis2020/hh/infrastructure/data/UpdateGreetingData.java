package com.thesis2020.hh.infrastructure.data;

public class UpdateGreetingData {
    public final String value;
    
    public UpdateGreetingData(final String value){
        this.value = value;
    }
}
