# vlingo-HelloWorld-In-Spring
imitating the vlingo-HelloWorld in Spring 
